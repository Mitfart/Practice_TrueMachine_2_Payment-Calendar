# Платёжный календарь — отчёт по API и внесённым исправлениям

Backend: Laravel + Sanctum (Bearer-токен), деньги — целые числа в копейках (`*_kopecks`), БД — PostgreSQL.

Все защищённые эндпоинты требуют заголовок:

```
Authorization: Bearer <token>
Accept: application/json
```

Токен выдаётся `/login` или `/register`.

---

## 0. Что исправлено по TASK_BACKEND_FIXES.md

| # | Было | Стало |
|---|------|-------|
| 1 | `priority` — любое целое число, `status` — любая строка до 50 символов | `priority: in:low,normal,high`, `status: in:draft,on_approval,approved,in_registry,paid,rejected` в `store` и `update` (`PaymentController`) |
| 2 | Календарь фильтровался только по `account_id` | Добавлены `item_id`, `counterparty_id`, `status` (для платежей); при передаче `status` заменяет дефолтный набор "закреплённых" статусов |
| 3 | В ответе календаря были только данные по каждому счёту | Добавлен ключ `summary.days` — приход/расход/остаток/признак кассового разрыва по всем выбранным счетам суммарно. Формат по счетам (`{account_id: {...}}`) не менялся |
| 4 | Реестр брал все `approved` заявки на дату без учёта остатка и приоритета | Заявки сортируются `high → normal → low`, добавляются в реестр только пока остаток на дату не уходит в минус; если ни одна не прошла — 422 с понятным сообщением |
| 5 | Истории изменений даты/суммы/статуса заявки не было (только `approvals` на решения руководителя) | Добавлена таблица `payment_changes` (`payment_id, user_id, field, old_value, new_value`), пишется при `update`, `submit`, `decide` |

Дополнительно: расчёт остатка по счёту вынесен в один сервис `App\Services\BalanceService`, чтобы формула `opening_balance + приходы − расходы` не дублировалась в `CalendarController`, `ReportController` и `RegistryController` (пункт «не распылять расчёт остатков» из ограничений). Новых зависимостей не добавлялось.

**Перед запуском нужно применить новую миграцию:**

```bash
cd backend
php artisan migrate
```

**Проверка** (в песочнице не было доступа к PHP/PostgreSQL, поэтому команды ниже нужно прогнать локально):

```bash
cd backend
php artisan test
# или, если тестов недостаточно:
php artisan route:list
php artisan migrate:fresh --seed
```

---

## 1. Аутентификация

### `POST /register` — публичный

```bash
curl -X POST http://localhost:8000/api/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Иван Иванов",
    "email": "ivan@example.com",
    "password": "secret123",
    "role": "initiator"
  }'
```

| Параметр | Тип | Обязателен | Примечание |
|---|---|---|---|
| name | string | да | ≤255 |
| email | string | да | уникальный, валидный email |
| password | string | да | ≥6 символов |
| role | string | да | `initiator`, `treasurer`, `manager`, `admin` |

Ответ: `{ "user": {...}, "token": "..." }`.

### `POST /login` — публичный

```bash
curl -X POST http://localhost:8000/api/login \
  -H "Content-Type: application/json" \
  -d '{ "email": "ivan@example.com", "password": "secret123" }'
```

Ответ: `{ "user": {...}, "token": "..." }`.

### `POST /logout` — авторизован

Отзывает текущий токен. Без параметров.

### `GET /me` — авторизован

Возвращает текущего пользователя.

---

## 2. Справочники: счета, контрагенты, статьи

### Счета `accounts`

| Метод | Путь | Роль | Тело запроса |
|---|---|---|---|
| GET | `/accounts` | любой авторизованный | — |
| GET | `/accounts/{id}` | любой авторизованный | — |
| POST | `/accounts` | `admin` | `name` (string, req), `currency` (3 символа, req), `opening_balance_kopecks` (int, req) |
| PUT/PATCH | `/accounts/{id}` | `admin` | те же поля, `sometimes` |
| DELETE | `/accounts/{id}` | `admin` | — |

```bash
curl -X POST http://localhost:8000/api/accounts \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"name":"Расчётный счёт","currency":"RUB","opening_balance_kopecks":1000000}'
```

### Контрагенты `counterparties` — полный `apiResource`, любой авторизованный

Поля: `name` (req), `inn`, `kpp`, `bank_account`, `bank_bik` (все опциональны при `update`).

### Статьи `items` — полный `apiResource`, любой авторизованный

Поля: `name` (req), `type` (req, например `income`/`expense`).

---

## 3. Заявки на платёж `payments`

### `GET /payments` — список со связями `account, counterparty, item, approvals`

### `POST /payments`

```bash
curl -X POST http://localhost:8000/api/payments \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{
    "account_id": 1,
    "counterparty_id": 2,
    "item_id": 3,
    "amount_kopecks": 500000,
    "payment_date": "2026-07-15",
    "purpose": "Оплата аренды",
    "priority": "high"
  }'
```

| Поле | Тип | Обязательно | Ограничение |
|---|---|---|---|
| account_id | int | да | существует в `accounts` |
| counterparty_id | int | да | существует в `counterparties` |
| item_id | int | да | существует в `items` |
| amount_kopecks | int | да | ≥1 |
| payment_date | date | да | — |
| purpose | string | нет | ≤1000 |
| priority | string | нет | **только** `low`, `normal`, `high` (по умолчанию `normal` на уровне БД) |
| status | string | нет | **только** `draft`, `on_approval`, `approved`, `in_registry`, `paid`, `rejected`; если не передан — `draft` |

### `GET /payments/{id}` — карточка заявки со связями `account, counterparty, item, approvals, changes`

### `PUT/PATCH /payments/{id}` — те же поля, что и в `store`, но `sometimes`; при изменении `payment_date`/`amount_kopecks`/`status` пишется запись в `payment_changes`

### `DELETE /payments/{id}`

### `POST /payments/{id}/submit` — роль `initiator`, `admin`

Переводит заявку `draft → on_approval`. Без тела запроса. 422, если заявка не в статусе `draft`.

### `POST /payments/{id}/decide` — роль `manager`, `admin`

```bash
curl -X POST http://localhost:8000/api/payments/5/decide \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"decision":"approved","comment":"Согласовано"}'
```

| Поле | Тип | Обязательно |
|---|---|---|
| decision | string | да, `approved` или `rejected` |
| comment | string | нет, ≤1000 |

422, если заявка не в статусе `on_approval`. Создаёт запись в `approvals` и запись в `payment_changes` (поле `status`).

---

## 4. Поступления `incomes` — полный `apiResource`, любой авторизованный

Поля: `account_id`, `counterparty_id`, `item_id` (все — существующие id), `amount_kopecks` (int ≥1), `income_date` (date). Все обязательны при `store`, `sometimes` при `update`.

---

## 5. Календарь `GET /calendar`

```bash
curl -G http://localhost:8000/api/calendar \
  -H "Authorization: Bearer $TOKEN" \
  --data-urlencode "from=2026-07-01" \
  --data-urlencode "to=2026-07-31" \
  --data-urlencode "account_id=1" \
  --data-urlencode "item_id=3" \
  --data-urlencode "counterparty_id=2" \
  --data-urlencode "status=paid"
```

| Параметр | Тип | Обязателен | Примечание |
|---|---|---|---|
| from | date | да | начало периода |
| to | date | да | ≥ `from` |
| account_id | int | нет | если не передан — все счета |
| item_id | int | нет | фильтр по статье (для приходов и расходов) |
| counterparty_id | int | нет | фильтр по контрагенту (для приходов и расходов) |
| status | string | нет | один из статусов заявки; если не передан — берутся `approved`, `in_registry`, `paid` (закреплённые) |

Ответ:

```json
{
  "1": {
    "account_name": "Расчётный счёт",
    "days": {
      "2026-07-01": { "income": 0, "expense": 50000, "balance": 950000, "is_gap": false },
      "...": "..."
    }
  },
  "summary": {
    "days": {
      "2026-07-01": { "income": 0, "expense": 50000, "balance": 950000, "is_gap": false },
      "...": "..."
    }
  }
}
```

Формат по счетам (ключ — `account_id`) не менялся, чтобы не сломать существующий фронт; `summary` — новый отдельный ключ с суммой по всем выбранным счетам за каждый день.

---

## 6. Реестры платежей `registries` — роль `treasurer`, `admin`

### `GET /registries` — список со связанными платежами

### `POST /registries`

```bash
curl -X POST http://localhost:8000/api/registries \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"account_id":1,"registry_date":"2026-07-15"}'
```

| Параметр | Тип | Обязательно |
|---|---|---|
| account_id | int | да |
| registry_date | date | да |

Логика:
1. Берутся только заявки со статусом `approved` на эту дату и счёт.
2. Сортируются по приоритету: `high → normal → low`.
3. Заявка включается в реестр, только если остаток на дату (без учёта ещё не пристроенных `approved`) после её включения остаётся ≥ 0.
4. Если подходящих заявок на дату вообще нет — `422 {"message": "Нет согласованных заявок на эту дату"}`.
5. Если заявки есть, но остатка не хватило ни на одну — `422 {"message": "Доступного остатка недостаточно ни для одной согласованной заявки на эту дату"}`.
6. Отобранные заявки переводятся в статус `in_registry`.

### `GET /registries/{id}` — карточка реестра с платежами

### `GET /registries/{id}/export` — CSV-выгрузка реестра (роль `treasurer`, `admin`)

### `POST /registries/{id}/mark-paid` — роль `treasurer`, `admin`

Переводит реестр и все его платежи в статус `paid`. 422, если реестр уже `paid`.

---

## 7. Отчёты `/reports/*` — роль `manager`, `treasurer`, `admin`

### `GET /reports/balances?date=2026-07-15`

Остаток по каждому счёту на дату (включительно), признак кассового разрыва.

### `GET /reports/upcoming-gaps?days=30`

Список дат/счетов, где прогнозный остаток уходит в минус в ближайшие `days` дней (по умолчанию 30, максимум 365).

### `GET /reports/plan-fact?from=2026-07-01&to=2026-07-31`

План по приходам/расходам (все незакрытые статусы, кроме `rejected`) и факт по расходам (`status = paid`) за период.

### `GET /reports/balances/export?date=2026-07-15`

CSV-версия `reports/balances`.

---

## Матрица ролей

| Роль | Доступно |
|---|---|
| `initiator` | справочники, свои заявки (`payments`), `submit` |
| `manager` | + `decide`, отчёты `/reports/*` |
| `treasurer` | + реестры (`registries`), отчёты |
| `admin` | всё, включая управление счетами (`accounts` создание/изменение/удаление) |

---

## Файлы, изменённые в этой итерации

- `app/Http/Controllers/PaymentController.php` — валидация `priority`/`status`, запись истории изменений
- `app/Http/Controllers/CalendarController.php` — фильтры `item_id`/`counterparty_id`/`status`, ключ `summary`
- `app/Http/Controllers/RegistryController.php` — приоритет + доступный остаток при формировании реестра
- `app/Http/Controllers/ReportController.php` — переиспользует `BalanceService` вместо дублирования формулы остатка
- `app/Services/BalanceService.php` — новый, единая точка расчёта остатка по счёту
- `app/Models/PaymentChange.php` — новая модель истории изменений заявки
- `app/Models/Payment.php` — добавлена связь `changes()`
- `database/migrations/2026_07_09_000000_create_payment_changes_table.php` — новая таблица `payment_changes`

Из необязательного блока ТЗ (повторяющиеся платежи, импорт файлов, Docker Compose, OpenAPI, полный экспорт отчётов, админка пользователей) — ничего не делалось, это осознанно вне минимального объёма задачи.

**Ограничение проверки:** в этой среде нет PHP/Composer/PostgreSQL, поэтому `php artisan test` и `migrate` не запускались — код проверен вручную (баланс скобок, типы, сигнатуры маршрутов). Перед мёржем стоит прогнать тесты и `migrate:fresh --seed` локально.
