<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\Payment;
use App\Models\Registry;
use App\Services\BalanceService;
use Illuminate\Http\Request;

class RegistryController extends Controller
{
    /**
     * Порядок приоритетов при формировании реестра: сначала high, потом normal, потом low.
     */
    private const PRIORITY_ORDER = ['high' => 1, 'normal' => 2, 'low' => 3];

    public function __construct(private readonly BalanceService $balanceService)
    {
    }

    public function index()
    {
        return Registry::with('payments')->get();
    }

    // Формирование реестра из согласованных заявок за дату:
    // берём только approved, идём по приоритету (high -> normal -> low)
    // и добавляем заявку, только если после неё остаток не уходит в минус.
    public function store(Request $request)
    {
        $validated = $request->validate([
            'account_id' => 'required|exists:accounts,id',
            'registry_date' => 'required|date',
        ]);

        $account = Account::findOrFail($validated['account_id']);
        $date = $validated['registry_date'];

        // Остаток на дату без учёта ещё не пристроенных 'approved' заявок —
        // это именно те заявки, которые сейчас распределяются в реестр.
        $availableBalance = $this->balanceService->balanceOnDate(
            $account,
            $date,
            BalanceService::REGISTRY_COMMITTED_STATUSES
        );

        $candidates = Payment::where('account_id', $account->id)
            ->where('status', 'approved')
            ->whereDate('payment_date', $date)
            ->get()
            ->sortBy(fn (Payment $payment) => self::PRIORITY_ORDER[$payment->priority] ?? 99)
            ->values();

        if ($candidates->isEmpty()) {
            return response()->json(['message' => 'Нет согласованных заявок на эту дату'], 422);
        }

        $selected = collect();
        $remaining = $availableBalance;

        foreach ($candidates as $payment) {
            // Деньги только в копейках, целыми числами, без float.
            if ($remaining - $payment->amount_kopecks >= 0) {
                $remaining -= $payment->amount_kopecks;
                $selected->push($payment);
            }
        }

        if ($selected->isEmpty()) {
            return response()->json([
                'message' => 'Доступного остатка недостаточно ни для одной согласованной заявки на эту дату',
            ], 422);
        }

        $registry = Registry::create([
            'account_id' => $validated['account_id'],
            'created_by' => $request->user()->id,
            'registry_date' => $validated['registry_date'],
            'status' => 'draft',
        ]);

        // Привязываем отобранные платежи к реестру в пивот-таблице
        $registry->payments()->attach($selected->pluck('id'));

        $selected->each(fn ($p) => $p->update(['status' => 'in_registry']));

        return $registry->load('payments');
    }

    public function show(Registry $registry)
    {
        return $registry->load('payments');
    }

    public function export(Registry $registry)
    {
        $registry->load('payments.account', 'payments.counterparty', 'payments.item');

        $csv = "Дата реестра,Счёт,Контрагент,Статья,Назначение,Сумма\n";
        foreach ($registry->payments as $payment) {
            $csv .= sprintf(
                "%s,%s,%s,%s,%s,%.2f\n",
                $registry->registry_date,
                $payment->account->name,
                $payment->counterparty->name,
                $payment->item->name,
                str_replace(',', ';', $payment->purpose ?? ''),
                $payment->amount_kopecks / 100
            );
        }

        $filename = 'registry_' . $registry->id . '_' . $registry->registry_date . '.csv';

        return response("\xEF\xBB\xBF" . $csv, 200, [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Content-Disposition' => "attachment; filename=\"$filename\"",
        ]);
    }

    // Отметить реестр как оплаченный — статус переходит на все платежи внутри
    public function markPaid(Registry $registry)
    {
        if ($registry->status === 'paid') {
            return response()->json(['message' => 'Реестр уже оплачен'], 422);
        }

        $registry->update(['status' => 'paid']);

        // Обновляем статус одним SQL-запросом для всех связанных платежей
        $registry->payments()->update(['status' => 'paid']);

        return $registry->load('payments');
    }
}
