<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UserController extends Controller
{
    // Список сотрудников — доступно админу и руководителю
    public function index()
    {
        return User::select('id', 'name', 'email', 'role', 'created_at')
            ->orderBy('created_at', 'desc')
            ->get();
    }

    // Создание учётной записи сотрудника с автогенерацией пароля
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'role' => 'required|in:initiator,treasurer,manager,admin',
        ]);

        // Str::password() формирует случайный пароль из букв разного регистра, цифр и спецсимволов
        $generatedPassword = Str::password(12);

        $user = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'password' => Hash::make($generatedPassword),
            'role' => $validated['role'],
        ]);

        // Пароль возвращается один раз, в открытом виде — дальше он нигде не хранится и не восстанавливается,
        // только хэш в базе. Фронтенд должен показать его администратору один раз (например, в модальном окне)
        return response()->json([
            'user' => $user,
            'generated_password' => $generatedPassword,
        ], 201);
    }

    // Удаление сотрудника — доступно админу и руководителю
    public function destroy(Request $request, User $user)
    {
        if ($request->user()->id === $user->id) {
            return response()->json(['message' => 'Нельзя удалить собственную учётную запись'], 422);
        }

        $user->delete();

        return response()->json(['message' => 'Сотрудник удалён']);
    }
}
