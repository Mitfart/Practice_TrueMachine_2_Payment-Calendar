<?php

namespace App\Services;

use App\Models\Account;
use App\Models\Income;
use App\Models\Payment;

/**
 * Единая точка расчёта остатков по счёту, чтобы не размазывать
 * одну и ту же формулу (opening_balance + приходы - расходы) по контроллерам.
 */
class BalanceService
{
    /**
     * Статусы заявок, которые уже "списывают" деньги со счёта при расчёте
     * остатков в календаре и отчётах (заявка согласована и дальше по конвейеру).
     */
    public const COMMITTED_STATUSES = ['approved', 'in_registry', 'paid'];

    /**
     * Статусы, которые считаются фактически зарезервированными/списанными
     * деньгами при формировании реестра. 'approved' сюда намеренно не входит —
     * это как раз те заявки, судьбу которых решает сам реестр.
     */
    public const REGISTRY_COMMITTED_STATUSES = ['in_registry', 'paid'];

    /**
     * Остаток по счёту на конкретную дату (включительно), в копейках.
     */
    public function balanceOnDate(Account $account, string $date, array $committedStatuses = self::COMMITTED_STATUSES): int
    {
        $incomeSum = Income::where('account_id', $account->id)
            ->where('income_date', '<=', $date)
            ->sum('amount_kopecks');

        $expenseSum = Payment::where('account_id', $account->id)
            ->whereIn('status', $committedStatuses)
            ->where('payment_date', '<=', $date)
            ->sum('amount_kopecks');

        return (int) $account->opening_balance_kopecks + (int) $incomeSum - (int) $expenseSum;
    }
}
